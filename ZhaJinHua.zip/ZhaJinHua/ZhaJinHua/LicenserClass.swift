//
//  LicenserClass.swift
//  ZhaJinHua
//
//  Created by 冯剑锋 on 16/7/21.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

import UIKit

//发牌员
class LicenserClass: NSObject {
    let pukes:NSMutableArray = NSMutableArray()
    
    override init() {
        super.init()
        resetPuke()
    }
    
    //重置牌组
    func resetPuke() {
        for color in 0...3{
            for point in 1...13{
                switch color {
                case 0:
                    let card = Card(designColor: DesignColors.redHeart, point: point)
                    pukes.addObject(card)
                    break
                case 1:
                    let card = Card(designColor: DesignColors.blackHeart, point: point)
                    pukes.addObject(card)
                    break
                case 2:
                    let card = Card(designColor: DesignColors.piece, point: point)
                    pukes.addObject(card)
                    break
                case 3:
                    let card = Card(designColor: DesignColors.blossom, point: point)
                    pukes.addObject(card)
                    break
                default: break
                }
            }
        }
    }
    
    //发牌
    func startLicensing() -> PukeCarCombol{
        let cardCombolArr = NSMutableArray()
        for _ in 0...3 {
            let num = Int(arc4random()%UInt32(pukes.count - 1))
            cardCombolArr.addObject(pukes[num])
            pukes.removeObjectAtIndex(num)
        }
        let pukeCom = PukeCarCombol(firstCards: cardCombolArr[0] as! Card, secondCards: cardCombolArr[1] as! Card, thirdCards: cardCombolArr[2] as! Card)
        return pukeCom
    }
}
