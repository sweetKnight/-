//
//  Player.swift
//  ZhaJinHua
//
//  Created by 冯剑锋 on 16/7/19.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

import UIKit

class Player: NSObject {
    var allMoney:Int = 0
    var cardCombol:PukeCarCombol?
    
    init(initMoney:Int) {
        allMoney = initMoney
    }
}
