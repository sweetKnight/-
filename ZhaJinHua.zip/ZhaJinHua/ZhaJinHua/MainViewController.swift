//
//  ViewController.swift
//  ZhaJinHua
//
//  Created by 冯剑锋 on 16/7/19.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

import UIKit
/// 相当于牌桌
class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let licenser = LicenserClass()
        let player1 = Player(initMoney: 500)
        let player2 = Player(initMoney: 500)
        player1.cardCombol = licenser.startLicensing()
        player2.cardCombol = licenser.startLicensing()
        player1.cardCombol?.getCardScore()
        player2.cardCombol?.getCardScore()
        if player1.cardCombol?.combolScore > player2.cardCombol?.combolScore {
            print("玩家1获胜")
        }else{
            print("玩家2获胜")
        }
        print(player1.cardCombol?.firstCard.points
            ,player1.cardCombol?.firstCard.designColor
            ,player1.cardCombol?.secondCard.points
            ,player1.cardCombol?.secondCard.designColor
            ,player1.cardCombol?.thirdCard.points
            ,player1.cardCombol?.thirdCard.designColor)
        print(player1.cardCombol?.combolScore)
        print("===========================================")
        print(player2.cardCombol?.firstCard.points
            ,player2.cardCombol?.firstCard.designColor
            ,player2.cardCombol?.secondCard.points
            ,player2.cardCombol?.secondCard.designColor
            ,player2.cardCombol?.thirdCard.points
            ,player2.cardCombol?.thirdCard.designColor)
        print(player2.cardCombol?.combolScore)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

