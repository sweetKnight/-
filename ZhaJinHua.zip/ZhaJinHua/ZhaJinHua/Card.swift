//
//  Card.swift
//  ZhaJinHua
//
//  Created by 冯剑锋 on 16/7/22.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

import UIKit

enum DesignColors {
    case redHeart    //红桃
    case blackHeart  //黑桃
    case piece       //方片
    case blossom     //梅花
}

//牌类
class Card {
    var designColor:DesignColors!
    var points:Int!
    init(designColor:DesignColors, point:Int){
        self.designColor = designColor
        self.points = point
    }
}
