//
//  PukeCarCombol.swift
//  ZhaJinHua
//
//  Created by 冯剑锋 on 16/7/21.
//  Copyright © 2016年 冯剑锋. All rights reserved.
//

import UIKit

let maxColorScore = 3*16+3*4+3 + 5  //花色能到最大值 加上5保险

let maxPointScore = 14*maxColorScore*maxColorScore*maxColorScore+14*maxColorScore*maxColorScore+14*maxColorScore + 200    //点数最高可到 加上200保险

enum CardType {
    case Flush         //同花顺  3000*5分加成
    case ArticleThree  //三条    3000*4分加成
    case Flowers       //同花    3000*3分加成
    case Shunza        //顺子    3000*2分加成
    case Pairs         //对子    3000分加成
    case Ordinary      //普通牌型 0分加成
}

//三张牌
class PukeCarCombol {
    var firstCard: Card!
    var secondCard: Card!
    var thirdCard: Card!
    var combolScore:Int!
    
    init(firstCards:Card, secondCards:Card, thirdCards:Card) {
        firstCard = firstCards
        secondCard = secondCards
        thirdCard = thirdCards
        cardCombolSorting()
    }
    
    //排序
    func cardCombolSorting() {
        var tempCar :Card?
        if secondCard.points < firstCard.points {
            tempCar = firstCard
            firstCard = secondCard
            secondCard = tempCar
        }
        if thirdCard.points < secondCard.points {
            tempCar = secondCard
            secondCard = thirdCard
            thirdCard = tempCar
            
            if secondCard.points < firstCard.points {
                tempCar = firstCard
                firstCard = secondCard
                secondCard = tempCar
            }
        }
    }
    
    //得到当前牌的分数
    func getCardScore() -> Int {
        let combolTypeScore = isFlush() + isArticleThree() + isLlowers() + isShunza() + isPairs()
        let pointScore = thirdCard.points * maxColorScore * maxColorScore * maxColorScore + secondCard.points * maxColorScore * maxColorScore + firstCard.points * maxColorScore
        let colorScore = getColorScore(thirdCard)*16+getColorScore(secondCard)*4+getColorScore(firstCard)
        combolScore = combolTypeScore+pointScore+colorScore
        return combolScore
    }
    
    //是否同花顺
    func isFlush() -> Int {
        if isLlowers() != 0 && isShunza() != 0{
            return maxPointScore*5
        }
        return 0
    }
    
    //是否是三条
    func isArticleThree() -> Int {
        if firstCard.points == secondCard.points && firstCard.points == thirdCard.points{
            return maxPointScore*4
        }
        return 0
    }
    
    //是否是同花
    func isLlowers() -> Int {
        if firstCard.designColor == secondCard.designColor && firstCard.designColor == thirdCard.designColor{
            return maxPointScore*3
        }
        return 0
    }
    //是否是顺子
    func isShunza() -> Int {
        if secondCard.points - firstCard.points == 1 && thirdCard.points - secondCard.points == 1{
            return maxPointScore*2
        }
        return 0
    }
    
    //是否是对子
    func isPairs() -> Int {
        if firstCard.points == secondCard.points || firstCard.points == thirdCard.points || secondCard.points == thirdCard.points{
            if isArticleThree() != 0{
               return 0
            }else{
              return maxPointScore
            }
        }
        return 0
    }
    
    func getColorScore(card:Card) -> Int{
        let color:DesignColors = card.designColor
        switch color {
        case .redHeart:
            return 3
        case .blackHeart:
            return 2
        case .piece:
            return 1
        case .blossom:
            return 0
        }
        
    }
}
